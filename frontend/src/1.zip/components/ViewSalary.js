// src/components/ViewSalary.js
import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import './ViewSalary.css';
import { FaEdit, FaTrash, FaTimes, FaSearch, FaArrowLeft } from 'react-icons/fa';

// EditSalaryModal component (can be in its own file or here for simplicity)
const EditSalaryModal = ({ salary, onClose, onSave }) => {
    const [editForm, setEditForm] = useState({
        basic: '',
        hra: '',
        allowance: ''
    });

    useEffect(() => {
        if (salary) {
            setEditForm({
                basic: salary.BASIC.toString(),
                hra: salary.HRA.toString(),
                allowance: salary.ALLOWANCE.toString()
            });
        }
    }, [salary]);

    const handleFormChange = (e) => {
        const { name, value } = e.target;
        setEditForm(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const updatedData = {
            BASIC: parseFloat(editForm.basic),
            HRA: parseFloat(editForm.hra),
            ALLOWANCE: parseFloat(editForm.allowance)
        };
        onSave(updatedData);
    };

    return (
        <div className="edit-modal">
            <div className="edit-modal-content">
                <div className="edit-modal-header">
                    <h2>Edit Salary Details</h2>
                    <button className="close-button" onClick={onClose}><FaTimes /></button>
                </div>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>EID:</label>
                        <input type="text" value={salary.EID} disabled />
                    </div>
                    <div className="form-group">
                        <label>Employee Name:</label>
                        <input type="text" value={`${salary.FIRSTNAME} ${salary.LASTNAME}`} disabled />
                    </div>
                    <div className="form-group">
                        <label>Basic Salary:</label>
                        <input
                            type="number"
                            name="basic"
                            value={editForm.basic}
                            onChange={handleFormChange}
                        />
                    </div>
                    <div className="form-group">
                        <label>HRA:</label>
                        <input
                            type="number"
                            name="hra"
                            value={editForm.hra}
                            onChange={handleFormChange}
                        />
                    </div>
                    <div className="form-group">
                        <label>Allowance:</label>
                        <input
                            type="number"
                            name="allowance"
                            value={editForm.allowance}
                            onChange={handleFormChange}
                        />
                    </div>
                    <div className="form-actions">
                        <button type="submit" className="save-btn">Save Changes</button>
                        <button type="button" className="cancel-btn" onClick={onClose}>Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const ViewSalary = () => {
    const [salaries, setSalaries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentSalary, setCurrentSalary] = useState(null);
    const [message, setMessage] = useState('');
    const [isSuccess, setIsSuccess] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredSalaries, setFilteredSalaries] = useState([]);

    const fetchSalaries = useCallback(async () => {
        try {
            setLoading(true);
            const response = await axios.get('http://localhost:5000/view-salary');
            const formattedSalaries = response.data.map(salary => ({
                ...salary,
                BASIC: parseFloat(salary.BASIC),
                HRA: parseFloat(salary.HRA),
                ALLOWANCE: parseFloat(salary.ALLOWANCE),
                SALARY: parseFloat(salary.SALARY),
            }));
            setSalaries(formattedSalaries);
            setError(null);
        } catch (err) {
            console.error("Failed to fetch salary data:", err);
            setError("Failed to load salary data. Please try again later.");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchSalaries();
    }, [fetchSalaries]);

    useEffect(() => {
        const query = searchQuery.toLowerCase().trim();
        let sortedSalaries = [];

        if (!query) {
            // Sort by EID in ascending order when no search query
            sortedSalaries = [...salaries].sort((a, b) => a.EID - b.EID);
        } else {
            const filtered = salaries.filter((salary) => {
                const eidMatch = salary.EID.toString().toLowerCase().includes(query);
                const nameMatch = `${salary.FIRSTNAME} ${salary.LASTNAME}`.toLowerCase().includes(query);
                return eidMatch || nameMatch;
            });
            // Sort filtered results by EID in ascending order
            sortedSalaries = filtered.sort((a, b) => a.EID - b.EID);
        }
        setFilteredSalaries(sortedSalaries);
    }, [searchQuery, salaries]);

    const handleClearSearch = () => {
        setSearchQuery('');
    };

    const openEditModal = (salary) => {
        setCurrentSalary(salary);
        setIsModalOpen(true);
    };

    const closeEditModal = () => {
        setIsModalOpen(false);
        setCurrentSalary(null);
    };

    const handleUpdate = async (updatedData) => {
        try {
            const response = await axios.put(`http://localhost:5000/update-salary/${currentSalary.EID}`, updatedData);
            if (response.data.success) {
                setMessage('Salary updated successfully!');
                setIsSuccess(true);
                closeEditModal();
                fetchSalaries();
            }
        } catch (err) {
            console.error("Error updating salary:", err);
            setMessage(err.response?.data?.message || 'Failed to update salary.');
            setIsSuccess(false);
            fetchSalaries(); // Refresh even on error to show the latest data
        }
    };

    const handleDeleteClick = async (eid) => {
        if (window.confirm("Are you sure you want to delete this salary record?")) {
            try {
                const response = await axios.delete(`http://localhost:5000/delete-salary/${eid}`);
                if (response.data.success) {
                    setMessage('Salary record deleted successfully!');
                    setIsSuccess(true);
                    fetchSalaries();
                }
            } catch (err) {
                console.error("Error deleting salary:", err);
                setMessage(err.response?.data?.message || 'Failed to delete salary.');
                setIsSuccess(false);
                fetchSalaries(); // Refresh even on error to show the latest data
            }
        }
    };

    if (loading) {
        return <div className="loading-message">Loading salary data...</div>;
    }

    if (error) {
        return <div className="error-message">{error}</div>;
    }

    return (
        <div className="view-salary-container">
            <h2>Salary Records</h2>

            <div className="controls">
                <div className="search-container">
                    <FaSearch className="search-icon" />
                    <input
                        type="text"
                        placeholder="Search by EID or name..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                </div>
                {searchQuery && (
                    <button className="back-btn" onClick={handleClearSearch}>
                        <FaArrowLeft className="back-icon" /> Back
                    </button>
                )}
            </div>

            {message && <div className={isSuccess ? 'success-message' : 'error-message'}>{message}</div>}
            {filteredSalaries.length === 0 ? (
                <p className="no-data-message">No salary data found.</p>
            ) : (
                <div className="table-container">
                    <table className="salary-table">
                        <thead>
                            <tr>
                                <th>EID</th>
                                <th>Employee Name</th>
                                <th>Basic</th>
                                <th>HRA</th>
                                <th>Allowance</th>
                                <th>Total Salary</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredSalaries.map((salary) => (
                                <tr key={salary.EID}>
                                    <td>{salary.EID}</td>
                                    <td>{`${salary.FIRSTNAME} ${salary.LASTNAME}`}</td>
                                    <td>₹{salary.BASIC.toFixed(2)}</td>
                                    <td>₹{salary.HRA.toFixed(2)}</td>
                                    <td>₹{salary.ALLOWANCE.toFixed(2)}</td>
                                    <td>₹{salary.SALARY.toFixed(2)}</td>
                                    <td className="actions">
                                        <button className="edit-btn" onClick={() => openEditModal(salary)}>
                                            <FaEdit />
                                        </button>
                                        <button className="delete-btn" onClick={() => handleDeleteClick(salary.EID)}>
                                            <FaTrash />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
            {isModalOpen && currentSalary && (
                <EditSalaryModal
                    salary={currentSalary}
                    onClose={closeEditModal}
                    onSave={handleUpdate}
                />
            )}
        </div>
    );
};

export default ViewSalary;