import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './FacultySalary.css';

function FacultySalary() {
  const location = useLocation();
  const navigate = useNavigate();
  const { eid, firstname } = location.state || {};
  const [salaryData, setSalaryData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!eid) {
      setError("No faculty ID provided.");
      return;
    }

    // This API call corresponds to the backend route you selected in the Canvas.
    axios.get(`http://localhost:5000/api/faculty/salary/${eid}`)
      .then(res => {
        if (res.data) {
          setSalaryData(res.data);
        } else {
          setError("No salary data found.");
        }
      })
      .catch(err => {
        console.error("Error fetching salary data:", err);
        if (err.response?.data?.error) {
          setError(err.response.data.error);
        } else {
          setError("Failed to fetch salary data.");
        }
      });
  }, [eid]);

  return (
    <div className="salary-container">
      <div className="salary-card">
        <h2>Salary Details for {firstname || "Faculty"}</h2>

        {error && <p className="error-message">{error}</p>}

        {salaryData && !error && (
          <table className="salary-table">
            <tbody>
              <tr><td><strong>Basic</strong></td><td>₹{salaryData.BASIC}</td></tr>
              <tr><td><strong>HRA</strong></td><td>₹{salaryData.HRA}</td></tr>
              <tr><td><strong>Allowance</strong></td><td>₹{salaryData.ALLOWANCE}</td></tr>
              <tr className="total-row"><td><strong>Total Salary</strong></td><td>₹{salaryData.SALARY}</td></tr>
            </tbody>
          </table>
        )}

        {!salaryData && !error && <p>Loading salary details...</p>}

        <button className="back-btn" onClick={() => navigate(-1)}>Back</button>
      </div>
    </div>
  );
}

export default FacultySalary;
