import axios from "axios";
import "./AddSalary.css";
import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

const AddSalary = () => {
  const navigate = useNavigate();
  const { employeeId } = useParams();

  const [salaryData, setSalaryData] = useState({
    EID: employeeId || "",
    BASIC: "",
    HRA: "",
    ALLOWANCE: "",
    SALARY: ""
  });

  const [errors, setErrors] = useState({});

  // Prefill EID from URL
  useEffect(() => {
    if (employeeId) {
      setSalaryData((prev) => ({ ...prev, EID: employeeId }));
    }
  }, [employeeId]);

  // Auto-calculate salary
  useEffect(() => {
    const basic = parseFloat(salaryData.BASIC) || 0;
    const hra = parseFloat(salaryData.HRA) || 0;
    const allowance = parseFloat(salaryData.ALLOWANCE) || 0;
    const total = basic + hra + allowance;
    setSalaryData((prev) => ({ ...prev, SALARY: total.toFixed(2) }));
  }, [salaryData.BASIC, salaryData.HRA, salaryData.ALLOWANCE]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSalaryData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    let newErrors = {};
    const requiredFields = ["EID", "BASIC", "HRA", "ALLOWANCE"];
    requiredFields.forEach((field) => {
      if (!salaryData[field] || salaryData[field].toString().trim() === "") {
        newErrors[field] = `${field} is required`;
      }
    });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      const res = await axios.post("http://localhost:5000/add-salary", salaryData);
      alert(res.data.message);
      navigate("/view-salary");
    } catch (error) {
      if (error.response && error.response.data && error.response.data.message) {
        alert(error.response.data.message);
      } else {
        alert("Error adding salary. Please try again.");
      }
    }
  };

  return (
    <div className="add-salary-container">
      <h2>Add Salary</h2>
      <form onSubmit={handleSubmit} className="salary-form">
        
        <div className="form-group compact">
          <label>Employee ID*</label>
          <input
            type="text"
            name="EID"
            value={salaryData.EID}
            onChange={handleChange}
            className={errors.EID ? "error-input" : ""}
            required
          />
          {errors.EID && <span className="error-message">{errors.EID}</span>}
        </div>

        <div className="form-group compact">
          <label>Basic*</label>
          <input
            type="number"
            name="BASIC"
            value={salaryData.BASIC}
            onChange={handleChange}
            className={errors.BASIC ? "error-input" : ""}
            required
          />
          {errors.BASIC && <span className="error-message">{errors.BASIC}</span>}
        </div>

        <div className="form-group compact">
          <label>HRA*</label>
          <input
            type="number"
            name="HRA"
            value={salaryData.HRA}
            onChange={handleChange}
            className={errors.HRA ? "error-input" : ""}
            required
          />
          {errors.HRA && <span className="error-message">{errors.HRA}</span>}
        </div>

        <div className="form-group compact">
          <label>Allowance*</label>
          <input
            type="number"
            name="ALLOWANCE"
            value={salaryData.ALLOWANCE}
            onChange={handleChange}
            className={errors.ALLOWANCE ? "error-input" : ""}
            required
          />
          {errors.ALLOWANCE && <span className="error-message">{errors.ALLOWANCE}</span>}
        </div>

        <div className="form-group compact">
          <label>Total Salary</label>
          <input
            type="number"
            name="SALARY"
            value={salaryData.SALARY}
            readOnly
          />
        </div>

        <div className="button-group">
          <button type="submit" className="submit-btn">Add Salary</button>
          <button type="button" className="back-btn" onClick={() => navigate(-1)}>Back</button>
        </div>
      </form>
    </div>
  );
};

export default AddSalary;
